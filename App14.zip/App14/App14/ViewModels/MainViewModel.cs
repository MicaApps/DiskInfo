﻿using System;

using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace App14.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        public MainViewModel()
        {
        }
    }
}
