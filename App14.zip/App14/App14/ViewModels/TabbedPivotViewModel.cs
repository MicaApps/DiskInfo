﻿using System;

using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace App14.ViewModels
{
    public class TabbedPivotViewModel : ObservableObject
    {
        public TabbedPivotViewModel()
        {
        }
    }
}
