﻿using System;

using App14.ViewModels;

using Windows.UI.Xaml.Controls;

namespace App14.Views
{
    public sealed partial class MainPage : Page
    {
        public MainViewModel ViewModel { get; } = new MainViewModel();

        public MainPage()
        {
            InitializeComponent();
        }
    }
}
