﻿using System;

using App14.ViewModels;

using Windows.UI.Xaml.Controls;

namespace App14.Views
{
    // TODO WTS: Change the icons and titles for all NavigationViewItems in ShellPage.xaml.
    public sealed partial class ShellPage2 : Page
    {
        public ShellViewModel ViewModel { get; } = new ShellViewModel();

        public ShellPage2()
        {
            InitializeComponent();
            DataContext = ViewModel;
            ViewModel.Initialize(shellFrame2, navigationView, KeyboardAccelerators);
        }
    }
}
