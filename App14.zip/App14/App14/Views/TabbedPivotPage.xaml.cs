﻿using System;

using App14.ViewModels;
using Syncfusion.UI.Xaml.BulletGraph;
using Windows.UI.Xaml.Controls;


namespace App14.Views
{
    public sealed partial class TabbedPivotPage : Page
    {
        public TabbedPivotViewModel ViewModel { get; } = new TabbedPivotViewModel();

        public TabbedPivotPage()
        {
            InitializeComponent();

            TopDataGrid.Navigate(typeof(DataGridPage));
            TopDataGrid2.Navigate(typeof(DataGridPage));
        }



    }
}
